'use strict';

global.auth = { username: "jtreehorn", password: "1comfort" }; // YOUR USERNAME AND PASSWORD FOR MYICOMFORT.COM GO HERE

const iComfort = new (require("icomfort"))(global.auth);

module.exports = iComfort;
